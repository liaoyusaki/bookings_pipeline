# Bookings Pipeline
TheFork assignment

## Requirements
You must have docker installed with at least 5GB of memory allocated to it

## Set up
Set up `.env` file as below:
 - **POSTGRES_USER_USERNAME**: Username for the _bookings_ database on postgres _(default: yulevern)_
 - **POSTGRES_USER_PASSWORD**: Password for the _bookings_ database on postgres _(default: thefork)_
 
## Steps
* Open a terminal in this directory
   ```bash
   cd bookings_pipeline
   ```
* Launch `docker-compose.yaml`
   ```bash
   docker-compose up
   ```
* Open airflow on `http://localhost:8080/`, the credentials are by default _airflow_ and _airflow_
* Trigger DAG _bookings_pipeline_
* The final dataset can be seen by connecting with a database tool(Datagrip, ...) to the _bookings_ database on port _5432_ with the credentials set in `.env`

## Discussion
### Summary
In this assignment, 50% of the difficulties that I encountered are related to docker, 30% are related to choosing strategies, 20% are related to Airflow.
### Docker part
* How to build a docker image with airflow and additional python dependencies installed?
  * Why => I didn't know the pandas, SQLAlchemy libraries were preinstalled within the Airflow image on docker hub, so I tried to make a customizable docker image with  airflow and additional python dependencies inside.
  * Final Solution => I managed to build a customizable image. But I found that all the libraries needed were preinstalled using the official `docker-compose.yaml`, so I chose to keep it simple.
* How to build another postgres database?
  * Why => I saw there was one default postgres database that holds only metadata, I thought it would be better to save the result table in another postgres database.
  * Final Solution => I modified `docker-compose.yaml` and `.env`, and added `init-db.sh`. (https://graspingtech.com/docker-compose-postgresql/)
  
### Strategies
* I built `transform`, `create_table` and `load_to_postgres` functions.
  * No extract here, because for a single csv in local it doesn't make sens.
  * Ideally, my design for a pipeline task would be: Extract(download/web scrapping...) -> Upload into a datalake(S3, GCS...) -> Transform -> Upload into S3, Copy from S3 into a data warehouse
* I passed the data between the tasks by using a local folder.
  * I tried to use xcom to pass the clean data, but I saw many discussions online saying this is not the best practice. (https://stackoverflow.com/questions/69868258/how-to-pass-pandas-dataframe-to-airflow-tasks)
  
### Airflow 
* I tried all three ways of creating DAGs and tasks in airflow.
  * I kept my script in functional programming style.
  * I think the decorator way seems to be the best, as it allows me to choose docker image. I managed to make it work with decorator but not really the same way as in their official doc, so I prefer to not submit with this version.

## Limitation
Here are some points that I would like to improve.
* Docker: Find a better/correct way to add and config database than the way I did.
* Strategies : Try to organise the tasks in OOP with airflow instead of functional programming, I usually prefer to do OOP than functional programming.
* Airflow : Try out custom operator, it seems really interesting. (https://airflow.apache.org/docs/apache-airflow/2.0.2/howto/custom-operator.html)
* Implement pipeline data validations.

## Feedback
Any questions or suggestions?
Please contact **liaoyuviyy@gmail.com**
