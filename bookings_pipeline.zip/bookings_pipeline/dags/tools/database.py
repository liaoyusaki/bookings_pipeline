import os
from sqlalchemy import create_engine


def postgres_engine(database: str, debug: bool = False):
    host = os.getenv("POSTGRES_HOST")
    user = os.getenv("POSTGRES_USER_USERNAME")
    password = os.getenv("POSTGRES_USER_PASSWORD")
    return create_engine(
        f"postgresql+psycopg2://{user}:{password}@{host}:5432/{database}", echo=debug
    )
