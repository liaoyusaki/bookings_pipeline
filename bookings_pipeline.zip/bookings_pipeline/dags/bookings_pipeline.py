import os
import logging

import pandas as pd
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago

from tools import postgres_engine


AIRFLOW_HOME = os.getenv("AIRFLOW_HOME")
RAW_DATA_DIR = os.path.join(AIRFLOW_HOME, "data", "raw_data")
CLEAN_DATA_DIR = os.path.join(AIRFLOW_HOME, "data", "clean_data")
RAW_FILE = "bookings.csv"
CLEAN_FILE = "monthly_bookings.csv"
TABLE_NAME = "monthly_restaurants_report"


def transform() -> None:
    """
    Transform raw data into clean data.
    """
    logging.info(f"All files under raw data are: {os.listdir(path=RAW_DATA_DIR)}")
    df = pd.read_csv(os.path.join(RAW_DATA_DIR, RAW_FILE))

    df["amount_norm"] = (
        df["amount"]
        .str.normalize("NFKD")
        .str.strip(" €£")
        .str.replace(",", ".", regex=True)
        .astype(float)
    )
    df["date_norm"] = pd.to_datetime(df["date"].str.strip(), dayfirst=True, errors="raise")
    df["month_norm"] = df["date_norm"].dt.strftime(date_format="%Y-%m")

    df_grouped = (
        df.groupby(["restaurant_id", "restaurant_name", "country", "month_norm"], as_index=False)
        .agg({"booking_id": "count", "guests": sum, "amount_norm": sum})
        .rename(
            columns={
                "month_norm": "month",
                "booking_id": "number_of_bookings",
                "guests": "number_of_guests",
                "amount_norm": "amount",
            }
        )
    )

    df_grouped.to_csv(os.path.join(CLEAN_DATA_DIR, CLEAN_FILE), index=False)


def create_table() -> None:
    """
    Create table structure if not exist in database.
    """
    conn = postgres_engine(database="bookings").connect()
    sql_cmd = f"""
            CREATE TABLE IF NOT EXISTS public.{TABLE_NAME} (
            restaurant_id TEXT,
            restaurant_name TEXT,
            country TEXT,
            month VARCHAR(8),
            number_of_bookings INT,
            number_of_guests INT, 
            amount REAL);
          """
    conn.execute(sql_cmd)
    conn.close()


def load_to_postgres() -> None:
    """
    Load clean data into data table.
    """
    engine = postgres_engine(database="bookings")

    df = pd.read_csv(os.path.join(CLEAN_DATA_DIR, CLEAN_FILE))
    df.to_sql(name=TABLE_NAME, schema="public", if_exists="replace", con=engine, index=False)


with DAG("bookings_pipeline", start_date=days_ago(1), schedule_interval=None) as dag:
    t1 = PythonOperator(task_id="transform", python_callable=transform)
    t2 = PythonOperator(task_id="create_table", python_callable=create_table)
    t3 = PythonOperator(task_id="load_to_postgres", python_callable=load_to_postgres)

    t1 >> t2 >> t3
